/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author PC
 */
public class TaiKhoan {
    private String ma_tai_khoan;
    private String ho;
    private String ten;
    private String email;
    private String mat_khau;
    private String so_dien_thoai;
    private int quyen_truy_cap;  
    private int tinh_trang;

    public TaiKhoan() {
    }

    public TaiKhoan(String ma_tai_khoan, String ho, String ten, String email, String mat_khau, String so_dien_thoai, int quyen_truy_cap, int tinh_trang) {
        this.ma_tai_khoan = ma_tai_khoan;
        this.ho = ho;
        this.ten = ten;
        this.email = email;
        this.mat_khau = mat_khau;
        this.so_dien_thoai = so_dien_thoai;
        this.quyen_truy_cap = quyen_truy_cap;
        this.tinh_trang = tinh_trang;
    }

    public String getMa_tai_khoan() {
        return ma_tai_khoan;
    }

    public void setMa_tai_khoan(String ma_tai_khoan) {
        this.ma_tai_khoan = ma_tai_khoan;
    }

    public String getHo() {
        return ho;
    }

    public void setHo(String ho) {
        this.ho = ho;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMat_khau() {
        return mat_khau;
    }

    public void setMat_khau(String mat_khau) {
        this.mat_khau = mat_khau;
    }

    public String getSo_dien_thoai() {
        return so_dien_thoai;
    }

    public void setSo_dien_thoai(String so_dien_thoai) {
        this.so_dien_thoai = so_dien_thoai;
    }

    public int getQuyen_truy_cap() {
        return quyen_truy_cap;
    }

    public void setQuyen_truy_cap(int quyen_truy_cap) {
        this.quyen_truy_cap = quyen_truy_cap;
    }

    public int getTinh_trang() {
        return tinh_trang;
    }

    public void setTinh_trang(int tinh_trang) {
        this.tinh_trang = tinh_trang;
    }

   

    
    
}
