/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import com.mysql.jdbc.Connection;
import connect.DBConnect;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ChiTietHoaDon;

/**
 *
 * @author PC
 */
public class ChiTietHoaDonDAOImp1 implements ChiTietHoaDonDAO{

    @Override
    public void themChiTietHD(ChiTietHoaDon cthd) {
           Connection cons = DBConnect.getConnection();
        String sql="INSERT INTO `chitiethoadon`(`ma_chi_tiet_hoa_don`, `ma_hoa_don`, `ma_san_pham`, `so_luong`, `don_gia`) VALUES (?,?,?,?,?)";   
        try {
            PreparedStatement ps = cons.prepareStatement(sql);
            ps.setString(1, cthd.getMa_chi_tiet_hoa_don());
            ps.setString(2, cthd.getHoa_don().getMa_hoa_don());
            ps.setString(3, cthd.getSan_pham().getMa_san_pham());
            
            ps.setInt(4, cthd.getSo_luong());
             ps.setDouble(5, cthd.getDon_gia());
             ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAOImp1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
