/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.TaiKhoan;

/**
 *
 * @author PC
 */
public interface TaiKhoanDAO {
    public boolean kiemTraTaiKhoan(String email);
    public void themTaiKhoan    (TaiKhoan tk);
    public boolean kiemTraMatKhau(String email, String mat_khau);
}
