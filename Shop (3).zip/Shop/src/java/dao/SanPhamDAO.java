/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import model.SanPham;

/**
 *
 * @author PC
 */
public interface SanPhamDAO {
    // lay danh sach dua theo ma danh muc
    public ArrayList<SanPham> getListProductByCategory(String ma_danh_muc);
    // hien thi thong tin chi tiet san pham
    public SanPham getChiTietSanPham(String ma_san_pham);
}
