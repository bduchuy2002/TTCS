/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import com.mysql.jdbc.Connection;
import connect.DBConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.TaiKhoan;
/**
 *
 * @author PC
 */
public class TaiKhoanDAOImp1 implements TaiKhoanDAO{

    @Override
    public boolean kiemTraTaiKhoan(String email) {
        Connection cons = DBConnect.getConnection();
        String sql="SELECT email FROM `taikhoan` WHERE email='"+email+"'";
        try {
            PreparedStatement ps = cons.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAOImp1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public void themTaiKhoan(TaiKhoan tk) {
        Connection cons = DBConnect.getConnection();
        String sql="INSERT INTO `taikhoan`(`ma_tai_khoan`, `ho`, `ten`, `email`, `mat_khau`, `so_dien_thoai`, `quyen_truy_cap`, `tinh_trang`) VALUES (?,?,?,?,?,?,?,?)";   
        try {
            PreparedStatement ps = cons.prepareStatement(sql);
            ps.setString(1, tk.getMa_tai_khoan());
            ps.setString(2, tk.getHo());
            ps.setString(3, tk.getTen());
            ps.setString(4,tk.getEmail());
            ps.setString(5, tk.getMat_khau());
            ps.setString(6, tk.getSo_dien_thoai());
            ps.setInt(7, tk.getQuyen_truy_cap());
             ps.setInt(8, tk.getTinh_trang());
             ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAOImp1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public boolean kiemTraMatKhau(String email, String mat_khau) {
        Connection cons = DBConnect.getConnection();
        String sql="SELECT * FROM `taikhoan` WHERE email ='"+email+"' and mat_khau='"+mat_khau+"'";
        try {
            PreparedStatement ps = cons.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAOImp1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
}
