/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import com.mysql.jdbc.Connection;
import connect.DBConnect;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.HoaDon;

/**
 *
 * @author PC
 */
public class HoaDonDAOImp1 implements HoaDonDAO{

    @Override
    public void themHoaDon(HoaDon hd) {
                Connection cons = DBConnect.getConnection();
        String sql="INSERT INTO `hoadon`(`ma_hoa_don`, `ma_tai_khoan`, `dia_chi_giao_hang`, `phuong_thuc_thanh_toan`, `ngay_mua_hang`, `tinh_trang_don_hang`) VALUES (?,?,?,?,?,?)";   
        try {
            PreparedStatement ps = cons.prepareStatement(sql);
            ps.setString(1, hd.getMa_hoa_don());
            ps.setString(2, hd.getTai_khoan().getMa_tai_khoan());
            ps.setString(3, hd.getDia_chi_giao_hang());
            ps.setString(4,hd.getPhuong_thuc_thanh_toan());
            ps.setTimestamp(5, hd.getNgay_mua_hang());       
            ps.setInt(6, hd.getTinh_trang_don_hang());         
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAOImp1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
