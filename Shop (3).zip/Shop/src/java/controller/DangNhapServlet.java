/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.TaiKhoanDAOImp1;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.TaiKhoan;

/**
 *
 * @author PC
 */
public class DangNhapServlet extends HttpServlet {

    private TaiKhoanDAOImp1 taiKhoanDAO = new TaiKhoanDAOImp1();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("command").equals("logout")){
            HttpSession session = request.getSession();
            session.invalidate();
            response.sendRedirect("/Shop/index.jsp");
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("Email");
        String mat_khau =request.getParameter("password");
        String err="";
        if(email.equals("") || mat_khau.equals("")){
            err="vui long nhap day du thong tin!";
        }else if(taiKhoanDAO.kiemTraMatKhau(email, mat_khau)==false){
             err="email hoac mat khau khong chinh xac!";
        }
        if(err.length()>0){
            request.setAttribute("err", err);
        }
        String url="/sign_up.jsp";
        try {
            if(err.equals("")){
                HttpSession session = request.getSession();
                session.setAttribute("user", email);
                 url = "/index.jsp";
            }else{
                url="/sign_up.jsp";
            }
            RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
            rd.forward(request, response);
        } catch (Exception e) {
        }
    }

   

}
