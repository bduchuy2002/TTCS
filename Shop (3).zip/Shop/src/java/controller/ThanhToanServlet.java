/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ChiTietHoaDonDAOImp1;
import dao.HoaDonDAOImp1;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ChiTietHoaDon;
import model.GioHang;
import model.HoaDon;
import model.SanPham;
import model.TaiKhoan;

/**
 *
 * @author PC
 */
public class ThanhToanServlet extends HttpServlet {

    private HoaDonDAOImp1 hdDAO = new HoaDonDAOImp1();
    private ChiTietHoaDonDAOImp1 cthdDAO = new ChiTietHoaDonDAOImp1();
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String dia_chi_giao_hang = request.getParameter("dia_chi_giao_hang");
        String phuong_thuc_thanh_toan =request.getParameter("phuong_thuc_thanh_toan");
        
        
        HttpSession session = request.getSession();
        GioHang cart = (GioHang) session.getAttribute("cart");
        
        try {
            Date date = new Date();
            String mhd = ""+date;
            TaiKhoan tk = new TaiKhoan();
            tk.getMa_tai_khoan();
            tk.setMa_tai_khoan("002");
            HoaDon hd = new HoaDon(mhd, tk,dia_chi_giao_hang,phuong_thuc_thanh_toan, new Timestamp(new Date().getTime()), 0);
            
            hdDAO.themHoaDon(hd);
           hd.setMa_hoa_don(mhd);
            TreeMap<SanPham, Integer> list = cart.getList();
            for(Map.Entry<SanPham, Integer> ds : list.entrySet() ){
                SanPham sp = new SanPham();
                sp.setMa_san_pham(ds.getKey().getMa_san_pham());
                cthdDAO.themChiTietHD(new ChiTietHoaDon(mhd, hd , sp , ds.getValue(),ds.getKey().getDon_gia()));
            } 
            response.sendRedirect("/Shop/index.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  
}
