/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.TaiKhoanDAOImp1;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.TaiKhoan;

/**
 *
 * @author PC
 */
public class DangKiServlet extends HttpServlet {
private TaiKhoanDAOImp1 taiKhoanDAO = new TaiKhoanDAOImp1();
   

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String ho = request.getParameter("firstname");
        String ten = request.getParameter("lastname");
        String email = request.getParameter("Email");
        String mat_khau =request.getParameter("password");
        String so_dien_thoai = request.getParameter("phone");
        
        String ho_err="";
        String ten_err="";
        String email_err="";
        String mat_khau_err="";
        String so_dien_thoai_err="";
        
        if(ho.equals("")){
            ho_err="không được để trống";
            
        }
        if(ho_err.length()>0){
            
            request.setAttribute("ho_err", ho_err);
        }
        if(ten.equals("")){
            ten_err="không được để trống";
        }
        if(ten_err.length()>0){
            request.setAttribute("ten_err", ten_err);
        }
        if(email.equals("")){
            email_err="không được để trống";
        }else if(taiKhoanDAO.kiemTraTaiKhoan(email)==true){
            email_err="địa chỉ email đã được đăng kí";
        }
        if(email_err.length()>0){
            request.setAttribute("email_err", email_err);
        }
        if(mat_khau.equals("")){
            mat_khau_err="không được để trống";
        }
        if(mat_khau_err.length()>0){
            request.setAttribute("mat_khau_err", mat_khau_err);
        }
        if(so_dien_thoai.equals("")){
            so_dien_thoai_err="không được để trống";
            
        }
        if(so_dien_thoai_err.length()>0){
            request.setAttribute("so_dien_thoai_err", so_dien_thoai_err);
        }
        String url = "/sign_up.jsp";
        try{
            if(mat_khau_err.length()==0 && ho_err.length()==0&&ten_err.length()==0&&email_err.length()==0&&so_dien_thoai_err.length()==0){
                Date id = new Date();
                
                TaiKhoan tk = new TaiKhoan(""+id.getTime(), ho, ten, email, mat_khau, so_dien_thoai, 1, 1);
                taiKhoanDAO.themTaiKhoan(tk);
                url = "/index.jsp";
                
            }else{
                url = "/sign_up.jsp";
            }
            RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
            rd.forward(request, response);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

  
    
}
